from regis import *

@bot.on(events.CallbackQuery(data=b'change_limits'))
async def change_limits_menu(event):
    inline_change_limits = [
        [Button.inline(" Change VMess IP Limit ","change_ip_limit vmess")],
        [Button.inline(" Change VMess Quota ","change_quota vmess")],
        [Button.inline(" Change VLESS IP Limit ","change_ip_limit vless")],
        [Button.inline(" Change VLESS Quota ","change_quota vless")],
        [Button.inline(" Change Trojan IP Limit ","change_ip_limit trojan")],
        [Button.inline(" Change Trojan Quota ","change_quota trojan")],
        [Button.inline(" Change Shadowsocks IP Limit ","change_ip_limit shadowsocks")],
        [Button.inline(" Change Shadowsocks Quota ","change_quota shadowsocks")],
        [Button.inline(" Back to Menu ","menu")]
    ]

    await event.edit("Choose an option:", buttons=inline_change_limits)
    
## testing aja

@bot.on(events.CallbackQuery(data_starts_with=b'change_ip_limit'))
async def handle_change_ip_limit(event):
    tunnel_type = event.data.decode("ascii").split()[1]
    user = input(f"Enter {tunnel_type.capitalize()} Username: ")
    iplimit = int(input(f"Enter new {tunnel_type.capitalize()} IP Limit: "))
   
    cmd = f'bash /root/regis/shell/bot-xray-ip {tunnel_type} {user} {iplimit}'.strip()
    try:
        subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.output}")
    else:
        print(f"{tunnel_type.capitalize()} IP Limit for {user} changed to {iplimit} successfully.")

@bot.on(events.CallbackQuery(data_starts_with=b'change_quota'))
async def handle_change_quota(event):
    tunnel_type = event.data.decode("ascii").split()[1]
    user = input(f"Enter {tunnel_type.capitalize()} Username: ")
    quota = input(f"Enter new {tunnel_type.capitalize()} Quota (GB): ")
    
    cmd = f'bash /path/to/your/script.sh {tunnel_type} {user} {quota}'.strip()
    try:
        subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.output}")
    else:
        print(f"{tunnel_type.capitalize()} Quota for {user} changed to {quota} GB successfully.")
